<?php $__env->startSection('body'); ?>

<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>New Absence</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('store-absences')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">
						 <label class="control-label" for="user_id">Employee</label>
						<div class="controls">
						<select class="span7" id="user_id"  name="user_id">
						   <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						     <option value="<?php echo e($em->user_id); ?>"><?php echo e($em->employee_id); ?></option>
						    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>

						<div class="control-group">
						 <label class="control-label" for="leave_type">Leave Type</label>
						<div class="controls">
						<select class="span7" id="leave_type"  name="leave_type">
                           <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						   <option value="<?php echo e($lv->leave_type); ?>"><?php echo e($lv->leave_type); ?></option>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">
						 <label class="control-label" for="leave_type">Reason</label>
						<div class="controls">
						<textarea  class="span7 h200" name="reason"></textarea>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">
						 <label class="control-label" for="date">Date</label>
						<div class="controls">
						<input type="text"  class="span7 " name="date" id="date">
						</div> <!-- /controls -->				
						</div>
						
						<button class="btn btn-primary">Submit</button>	
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<div class="row">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Leave Type</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table id="example" class="display nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Leave Type</th>
                <th>Reason</th>
                <th>Date</th>
                <th>Action</th>
                
            </tr>
        </thead>
        <tfoot>
            <tr>
         
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
        	<?php $__currentLoopData = $absences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($ab->employee->employee_id); ?></td>
                <td><?php echo e($ab->user->name); ?></td>
                <td><?php echo e($ab->leave_type); ?></td>
                <td><?php echo e($ab->reason); ?></td>
                <td><?php echo e($ab->date); ?></td>
                <td style="float: right;">
				<div class="controls">
				<div class="btn-group">
				<a class="btn btn-success" href="#"><i class="icon-plus icon-white"></i> Action</a>
				<a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#"><span class="caret"></span></a>
				 <ul class="dropdown-menu" style="min-width:100px;">
				        <li><a href="<?php echo e(route('edit-absences',$ab->id)); ?>"><i class="icon-pencil"></i> Edit</a></li>
				         <li>
				         	<a href="<?php echo e(route('delete-absences',$ab->id)); ?>"><i class="icon-trash"></i> Delete</a>
				         </li>
			
				        </ul>
				</div>
				</div>
                 </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#date').datepicker();
	$('#user_id').select2();
	$('#leave_type').select2();
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>