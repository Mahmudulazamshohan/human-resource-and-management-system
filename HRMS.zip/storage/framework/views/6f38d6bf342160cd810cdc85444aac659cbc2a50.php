<?php $__env->startSection('body'); ?>
<?php if($absences): ?>
<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Edit Absence</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('update-absences')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

                         <input type="hidden" name="user_id" value="<?php echo e($absences->user_id); ?>">
						 <div class="control-group">
						 <label class="control-label" for="user_id">Employee</label>
						<div class="controls">
						<select class="span7" id="user_id"   disabled>
						   <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						     <?php if($em->user_id == $absences->user_id ): ?>
						     <option value="<?php echo e($em->user_id); ?>" selected><?php echo e($em->employee_id); ?></option>
						     <?php else: ?>
                               <option value="<?php echo e($em->user_id); ?>"><?php echo e($em->employee_id); ?></option>
						     <?php endif; ?>
						    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>

						<div class="control-group">
						 <label class="control-label" for="leave_type">Leave Type</label>
						<div class="controls">
						<select class="span7" id="leave_type"  name="leave_type">
                           <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($lv->leave_type == $absences->leave_type ): ?>
						   <option value="<?php echo e($lv->leave_type); ?>" selected><?php echo e($lv->leave_type); ?></option>
						   <?php else: ?>
						   <option value="<?php echo e($lv->leave_type); ?>"><?php echo e($lv->leave_type); ?></option>
						   <?php endif; ?>

						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">
						 <label class="control-label" for="leave_type">Reason</label>
						<div class="controls">
						<textarea  class="span7 h200" name="reason"><?php echo e($absences->reason); ?></textarea>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">
						 <label class="control-label" for="date">Date</label>
						<div class="controls">
						<input type="text"  class="span7 " name="date" id="date" value="<?php echo e($absences->date); ?>">
						</div> <!-- /controls -->				
						</div>
						
						<button class="btn btn-primary">Submit</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<?php else: ?>
<div class="container">
	
	<div class="row">
		
		<div class="span12">
			
			<div class="error-container">
				<h1>404</h1>
				
				<h2>Who! bad trip man. No more pixesl for you.</h2>
				
				<div class="error-details">
					Sorry, an error has occured! Why not try going back to the <a href="<?php echo e(route('dashboard')); ?>">home page</a> or perhaps try following!
					
				</div> <!-- /error-details -->
				
				<div class="error-actions">
					<a href="<?php echo e(route('dashboard')); ?>" class="btn btn-large btn-primary">
						<i class="icon-chevron-left"></i>
						&nbsp;
						Back to Dashboard						
					</a>
					
					
					
				</div> <!-- /error-actions -->
							
			</div> <!-- /error-container -->			
			
		</div> <!-- /span12 -->
		
	</div> <!-- /row -->
	
</div>
<?php endif; ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#date').datepicker();
	$('#user_id').select2();
	$('#leave_type').select2();
	$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>