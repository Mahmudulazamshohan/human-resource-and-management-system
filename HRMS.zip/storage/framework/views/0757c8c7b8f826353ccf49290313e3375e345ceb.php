<?php $__env->startSection('body'); ?>


<div class="row">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Employee List</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table id="example" class="display nowrap" cellspacing="0" width="100%">
        <thead>
            <tr style="text-align: left;">
                <th>Employee ID</th>
                <th>Name</th>
                <th>Month</th>
                <th>Workday(hours)</th>
                <th>Overtime(hours)</th>
                <th>Tardiness</th>
               
                
            </tr>
        </thead>
        <tfoot>
            <tr>
               
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
             
                
            </tr>
        </tfoot>
        <tbody>
           <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php echo e($s->employee_id); ?></td>
                <td><?php echo e($s->name); ?></td>
                <td><?php echo e($s->month); ?></td>
                <td><?php echo e(floor($s->hour_worked/3600)); ?> hours <?php echo e(($s->hour_worked/ 60) % 60); ?> minutes</td>
                <td><?php echo e(floor($s->overtime/3600)); ?> hours <?php echo e(($s->overtime/ 60) % 60); ?> minutes</td>
                <td><?php echo e($s->tardiness/3600); ?> hours <?php echo e(($s->tardiness/ 60) % 60); ?> minutes</td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
          
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        scrollY:true,
    });
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>