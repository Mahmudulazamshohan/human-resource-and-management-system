<?php $__env->startSection('body'); ?>


<div class="row" style="margin-bottom: 10%;">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Department List</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table id="example" class="display nowrap" cellspacing="0" width="100%">
        <thead>
            <tr style="text-align: left;">
                <th>Employee ID</th>
                <th>Account</th>
                <th>Gender</th>
                <th>Email </th>
                <th>Department</th>
                <th>Designation</th>
                <th>Role </th>
                <th>Action</th>
                
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($em->employee_id); ?></td>
                <td><?php echo e($em->user->name); ?></td>
                <td><?php echo e($em->gender); ?></td>
                <td><?php echo e($em->user->email); ?></td>
                <td>
                    <?php echo e($em->department); ?>

                </td>
                <td><?php echo e($em->designation); ?></td>
                <td>
                    <?php if(DB::table('role_admins')
                             ->where('user_id',$em->user_id)
                             ->first()->role_id === 3): ?>
                             <?php echo e("Employee"); ?> 
                    <?php elseif(DB::table('role_admins')
                             ->where('user_id',$em->user_id)
                             ->first()->role_id === 2): ?>
                             <?php echo e("Manager"); ?> 
                    <?php else: ?>
                             <?php echo e("Admin"); ?>

                    <?php endif; ?>
                </td>
                <td>
				<div class="controls">
				<div class="btn-group">
				<a class="btn btn-success" href="#"><i class="icon-plus icon-white"></i> Action</a>
				 <a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#"><span class="caret"></span></a>
				    <ul class="dropdown-menu" style="min-width:100px;">
				        <li><a href="<?php echo e(route('edit-employee',$em->id)); ?>"><i class="icon-pencil"></i> Edit/View</a></li>
				         
			
				        </ul>
				  </div>
				</div>
                 </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>