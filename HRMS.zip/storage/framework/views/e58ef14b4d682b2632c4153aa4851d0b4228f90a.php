<?php $__env->startSection('body'); ?>

<?php if($departments): ?>
<div class="row" style="margin-bottom: 10%;">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Edit Department</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
					
						<form action="<?php echo e(route('update-departments')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">											
						<input type="hidden" name="id" value="<?php echo e($departments->id); ?>">	
						<label class="control-label" for="department">Department Name</label>
						<div class="controls">
						<input type="text" class="span7" id="department" placeholder="Department Name" name="department" value="<?php echo e($departments->department); ?>">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
						<label class="control-label" for="designation">Designation</label>
						<div class="controls">
						<input type="text" class="span7" id="designation" placeholder="Designation Name" name="designation" value="<?php echo e($departments->designation); ?>">
						</div> <!-- /controls -->				
						</div>
						<button class="btn btn-primary">Update</button>	
						</div>
						</form>
						
						 
						
					</div>
				</div>
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<?php else: ?>
<div class="container">
	
	<div class="row">
		
		<div class="span12">
			
			<div class="error-container">
				<h1>404</h1>
				
				<h2>Who! bad trip man. No more pixesl for you.</h2>
				
				<div class="error-details">
					Sorry, an error has occured! Why not try going back to the <a href="<?php echo e(route('dashboard')); ?>">home page</a> or perhaps try following!
					
				</div> <!-- /error-details -->
				
				<div class="error-actions">
					<a href="<?php echo e(route('dashboard')); ?>" class="btn btn-large btn-primary">
						<i class="icon-chevron-left"></i>
						&nbsp;
						Back to Dashboard						
					</a>
					
					
					
				</div> <!-- /error-actions -->
							
			</div> <!-- /error-container -->			
			
		</div> <!-- /span12 -->
		
	</div> <!-- /row -->
	
</div>
<?php endif; ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>