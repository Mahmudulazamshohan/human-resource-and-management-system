<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>
        Page Not found
    </title>
    <style type="text/css">
        h1{
            text-align: center;
            color: #555;
            
        }
    </style>
</head>
<body>
    <h1>Page not found</h1>
</body>
</html>
