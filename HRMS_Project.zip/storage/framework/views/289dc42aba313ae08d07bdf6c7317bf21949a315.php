<?php $__env->startSection('body'); ?>

<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Staff Scheduling Classes</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('store-staff-scheduling')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">											
							
						<label class="control-label" for="user_id">Employee ID</label>
						<div class="controls">
						<select class="span7" id="user_id" name="user_id">
							<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <option value="<?php echo e($em->user_id); ?>"><?php echo e($em->employee_id); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
						<label class="control-label" for="date">Date</label>
						<div class="controls">
						<input type="text" class="span7" id="date" placeholder="Date" name="date">
						</div> <!-- /controls -->				
						</div>

						<div class="control-group">											
						<label class="control-label" for="time_in">Time In</label>
						<div class="controls">
						<input type="text" class="span7" id="time_in" placeholder="Time In" name="time_in">
						</div> <!-- /controls -->				
						</div>

						<div class="control-group">											
						<label class="control-label" for="time_out">Time Out</label>
						<div class="controls">
						<input type="text" class="span7" id="time_out" placeholder="Time Out" name="time_out">
						</div> <!-- /controls -->				
						</div>

						<button class="btn btn-primary">Submit</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<div class="row">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Department List</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table id="example" class="display nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>ID</th>	
                <th>Name</th>	
                <th>Date</th>	
                <th>Time In</th>	
                <th>Time Out</th>	
                <th>Hours Worked</th>	
                <th>Tardiness</th>	
                <th>Overtime</th>	
                <th>Action</th>
                
                
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
          <?php $__currentLoopData = $staff_scheduling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            	<td><?php echo e($ss->employee->employee_id); ?></td>
            	<td><?php echo e($ss->user->name); ?></td>
            	<td><?php echo e($ss->date); ?></td>
                <td><?php echo e($ss->time_in); ?></td>
                <td><?php echo e($ss->time_out); ?></td>
                <td><?php echo e($ss->hours_worked_str); ?></td>
                <td><?php echo e($ss->tardiness_str); ?></td>
                <td><?php echo e($ss->overtime_str); ?></td>
                <td>
				<div class="controls">
				<div class="btn-group">
				<a class="btn btn-success" href="#"><i class="icon-plus icon-white"></i> Action</a>
				<a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#"><span class="caret"></span></a>
				<ul class="dropdown-menu">
				
				<li><a href="<?php echo e(route('delete-staff-scheduling',$ss->id)); ?>"><i class="icon-trash"></i> Delete</a></li>
			
				</ul>
				</div>
				</div>
                 </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('public/js/jquery-ui-timepicker-addon.js')); ?>"></script>

<script type="text/javascript">
	
	$('#date').datepicker();
	$('#time_in').timepicker({
	      timeFormat: 'hh:mm tt'
    });
    $('#time_out').timepicker({
	      timeFormat: 'hh:mm tt'
    });
	$('#user_id').select2();
	$(document).ready(function() {
    // $('#example').DataTable( {
    //     dom: 'Bfrtip',
    //     buttons: [
    //         'copy', 'csv', 'excel', 'pdf', 'print'
    //     ]
    // } );
    $('#example').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>