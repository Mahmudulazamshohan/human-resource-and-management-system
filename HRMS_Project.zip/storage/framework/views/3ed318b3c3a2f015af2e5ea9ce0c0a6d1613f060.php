<?php $__env->startSection('body'); ?>
<?php if($ls): ?>
<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Edit Leaves</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('manager/update-leaves')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">											
						<input type="hidden" name="employee_id" value="<?php echo e($ls->user_id); ?>">	
						<label class="control-label" for="user_id">Employee ID </label>
						<div class="controls">
						<select class="span7" id="user_id"  name="user_id">
							<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <?php if($e->user_id == $ls->user_id): ?>

							    <option value="<?php echo e($e->user_id); ?>" selected><?php echo e($e->employee_id); ?></option>
							  <?php else: ?>
							    <option value="<?php echo e($e->user_id); ?>"><?php echo e($e->employee_id); ?></option>
							  <?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="leave_type">Leave Type</label>
						<div class="controls">
						<select class="span7" id="leave_type"  name="leave_type">
							<?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <?php if($l->leave_type == $ls->leave_type): ?>
							    <option value="<?php echo e($l->leave_type); ?>" selected><?php echo e($l->leave_type); ?></option>
							  <?php else: ?>
							    <option value="<?php echo e($l->leave_type); ?>"><?php echo e($l->leave_type); ?></option>
							  <?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="date_from">Date From</label>
						<div class="controls">
						<input type="text" class="span7" id="date_from" placeholder="Date From" name="date_from" value="<?php echo e($ls->date_from); ?>">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="date_to">Date To</label>
						<div class="controls">
						<input type="text" class="span7" id="date_to" placeholder="Date To" name="date_to" value="<?php echo e($ls->date_to); ?>">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="applied_on">Applied On</label>
						<div class="controls">
						<input type="text" class="span7" id="applied_on" placeholder="Applied On" name="applied_on" value="<?php echo e($ls->applied_on); ?>">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="leave_type">Reason</label>
						<div class="controls">
						<textarea class="span7" id="reason"  name="reason" style="min-height:70px; min-width:48.79941434846266%; "><?php echo e($ls->reason); ?></textarea>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="comment">Comment</label>
						<div class="controls">
						
						<textarea class="span7" id="comment"  name="comment" style="min-height:70px;min-width:48.79941434846266%; "><?php echo e($ls->comment); ?></textarea>
						</div> <!-- /controls -->				
						</div>

						
						<button class="btn btn-primary">Submit</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<?php else: ?>
<div class="container">
    
    <div class="row">
        
        <div class="span12">
            
            <div class="error-container">
                <h1>404</h1>
                
                <h2>Who! bad trip man. No more pixesl for you.</h2>
                
                <div class="error-details">
                    Sorry, an error has occured! Why not try going back to the <a href="<?php echo e(route('dashboard')); ?>">home page</a> or perhaps try following!
                    
                </div> <!-- /error-details -->
                
                <div class="error-actions">
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-large btn-primary">
                        <i class="icon-chevron-left"></i>
                        &nbsp;
                        Back to Dashboard                       
                    </a>
                    
                    
                    
                </div> <!-- /error-actions -->
                            
            </div> <!-- /error-container -->            
            
        </div> <!-- /span12 -->
        
    </div> <!-- /row -->
    
</div>
<?php endif; ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#user_id').select2();
	$('#leave_type').select2();
	$('#date_from').datepicker();
	$('#date_to').datepicker();
	$('#applied_on').datepicker();
	$(document).ready(function() {
    $('#example').DataTable({
    	scrollY:150,
    	scrollX:true
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>