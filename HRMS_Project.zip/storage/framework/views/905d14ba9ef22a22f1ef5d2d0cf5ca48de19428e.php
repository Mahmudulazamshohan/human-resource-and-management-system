<?php $__env->startSection('body'); ?>
<?php if($employee): ?>
<form action="<?php echo e(route('update-employee')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
<div class="row">
      
       <div class="span6">
       
          <div class="widget ">
                    
                    <div class="widget-header">
                        <i class="icon-plus"></i>
                        <h3>Personal Details</h3>
                    </div> <!-- /widget-header -->
                    
                    <div class="widget-content">
                        <div class="container">
                       
                           
                         <div class="control-group">                                            
                            
                        <label class="control-label" for="name">Name <i class="icon-asterisk icon-sm"></i></label>
                        <div class="controls">
                        <input type="text" class="span5" id="name" placeholder="Name" name="username" value="<?php echo e($employee->user->name); ?>">
                        </div> <!-- /controls -->               
                        </div>
                        <div class="control-group">                                         
                        <label class="control-label" for="designation">Father's Name</label>
                        <div class="controls">
                        <input type="text" class="span5" id="designation"  name="father_name" 
                        <?php if($employee->father_name!= null): ?>
                        value="<?php echo e($employee->father_name); ?>" 
                        <?php else: ?> 
                        placeholder="Null"
                        <?php endif; ?>
                        >
                        </div> <!-- /controls -->               
                        </div>
                         <div class="control-group">                                         
                        <label class="control-label" for="date_of_birth">Date of Birth</label>
                        <div class="controls">
                        <input type="text" class="span5" id="date_of_birth" name="date_of_birth"
                        <?php if($employee->date_of_birth!= null): ?>
                        value="<?php echo e($employee->date_of_birth); ?>" 
                        <?php else: ?> 
                        placeholder="Null"
                        <?php endif; ?>
                        >
                        </div> <!-- /controls -->               
                        </div>

                         <div class="control-group">                                         
                        <label class="control-label" for="designation">Gender</label>
                        <div class="controls">
                        <select name="gender">
                            <option>Male</option>
                            <option>Female</option>
                        </select>
                        </div> <!-- /controls -->               
                        </div>
                        <div class="control-group">                                         
                        <label class="control-label" for="designation">Phone Number</label>
                        <div class="controls">
                        <input type="text" class="span5" id="designation" name="phone_number"
                        <?php if($employee->phone_number!= null): ?>
                        value="<?php echo e($employee->phone_number); ?>" 
                        <?php else: ?> 
                        placeholder="Null"
                        <?php endif; ?>
                        >
                        </div> <!-- /controls -->               
                        </div>
                        <div class="control-group">                                         
                        <label class="control-label" >Local Address</label>
                        <div class="controls">
                        <textarea class="span5"  name="local_address" style="height: 50px;">
                            <?php if($employee->local_address): ?>
                             <?php echo e($employee->local_address); ?>

                            <?php endif; ?>
                        </textarea>
                        </div> <!-- /controls -->               
                        </div>
                        <div class="control-group">                                         
                        <label class="control-label" >Permanent Address</label>
                        <div class="controls">
                        <textarea class="span5" name="permanent_address" style="height: 50px;">
                             <?php if($employee->permanent_address): ?>
                              <?php echo e($employee->permanent_address); ?>

                              <?php endif; ?>
                        </textarea>
                        </div> <!-- /controls -->               
                        </div>
                     
                        </div>
                      

                        
                    </div>
                </div>
                
            
            
             <div class="widget ">
                    
                    <div class="widget-header">
                        <i class="icon-plus"></i>
                        <h3>Company Details</h3>
                    </div> <!-- /widget-header -->
                    
                    <div class="widget-content">
                        <div class="container">  
                    
                         <div class="control-group">                                            
                            
                        <label class="control-label" for="department">Employee ID <i class="icon-asterisk icon-sm"></i></label>
                        <div class="controls">
                        <input type="text" class="span5" id="department"  name="employee_id"
                        <?php if($employee->employee_id!= null): ?>
                        value="<?php echo e($employee->employee_id); ?>" 
                        <?php else: ?> 
                        placeholder="Null"
                        <?php endif; ?>
                         disabled 
                        >
                        </div> <!-- /controls -->               
                        </div>
    

                         <div class="control-group">                                         
                        <label class="control-label" for="designation">Department</label>
                        <div class="controls">
                        <select class="option-auto" style="width: 40.55344070278184%;" id="department-section" name="department" disabled >
                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                          <option value="<?php echo e($dp->department); ?>"><?php echo e($dp->department); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div> <!-- /controls -->               
                        </div>
                         <div class="control-group">                                         
                        <label class="control-label" for="designation">Designation</label>
                        <div class="controls">
                        <select id="designation-section" style="width: 40.55344070278184%;" name="designation" disabled >

                          <option><?php echo e($employee->designation); ?></option>
                        </select>
                        </div> <!-- /controls -->               
                        </div>
                        <div class="control-group">                                         
                        <label class="control-label" for="designation">Date of joining</label>
                        <div class="controls">
                        <input type="text" class="span5" id="date_of_birth2"  name="date_of_joining"
                        <?php if($employee->date_of_joining!= null): ?>
                        value="<?php echo e($employee->date_of_joining); ?>" 
                        <?php else: ?> 
                        placeholder="Null"
                        <?php endif; ?>
                        >
                        </div> <!-- /controls -->               
                        </div>
                        <div class="control-group">                                         
                        <label class="control-label" for="designation">Joining Salary</label>
                        <div class="controls">
                        <input type="text" class="span5" id="designation"  name="joining_salary"
                        <?php if($employee->joining_salary!= null): ?>
                        value="<?php echo e($employee->joining_salary); ?>" 
                        <?php else: ?> 
                        placeholder="Null"
                        <?php endif; ?>
                        >
                        </div> <!-- /controls -->               
                        </div>
                      
                        </div>
                       

                        
                    </div>
                </div>
                    
       </div>
       
           
       <div class="span6">
           <div class="widget ">
                    
                    <div class="widget-header">
                        <i class="icon-plus"></i>
                        <h3>Account Login</h3>
                    </div> <!-- /widget-header -->
                    
                    <div class="widget-content">
                         <div class="container">
                        
                            
                         
                        <div class="control-group">                                         
                        <label class="control-label" for="email">Email  <i class="icon-asterisk icon-sm"></i></label>
                        <div class="controls">
                        <input type="text" class="span5" id="email" placeholder="Email" name="email"
                        <?php if($employee->user->email!= null): ?>
                        value="<?php echo e($employee->user->email); ?>" 
                        <?php else: ?> 
                        placeholder="Null"
                        <?php endif; ?>
                        disabled 
                        >
                        </div> <!-- /controls -->               
                        </div>
                         <div class="control-group">                                         
                        <label class="control-label" for="designation">New Password <i class="icon-asterisk icon-sm"></i></label>
                        <div class="controls">
                        <input type="text" class="span5" id="designation" placeholder="Enter new password" name="password" disabled="">
                        </div> <!-- /controls -->               
                        </div>

                         <div class="control-group">                                         
                        <label class="control-label" for="designation">User Role <i class="icon-asterisk icon-sm"></i></label>
                        <div class="controls">
                        <select class="option-auto" style="width: 40.55344070278184%;" name="user_role" disabled="">
                          <option value="3">Employee</option>
                          <option value="2">Manager</option>
                          <option value="1">Admin</option>
                          
                        </select>
                        </div> <!-- /controls -->               
                        </div>
                      
                        </div>
                    
                    </div>
          </div>

          <div class="widget ">
                    
                    <div class="widget-header">
                        <i class="icon-plus"></i>
                        <h3>Upload</h3>
                    </div> <!-- /widget-header -->
                    
                    <div class="widget-content">
                         <div class="container">
                            <div style="display: grid;">
                               <input type="file" name="image_file" id="image_preview" class="custom-file-input" style="height: 38px;" accept="image/png, image/jpeg, image/gif">
                                   <?php if($employee->image_preview_location!=null): ?>
                                    <img src="<?php echo e(asset('storage/app/'.$employee->image_preview_location)); ?>" id="preview_image" width="200px" >

                                   <?php else: ?>
                                     <img src="<?php echo e(asset('public/img/blank-profile.png')); ?>" id="preview_image" width="200px" >
                                   <?php endif; ?>
                                  

                            </div>
                            <div style="margin-top: 10px;"><a href="<?php echo e(asset('storage/app/'.$employee->image_preview_location)); ?>" class="btn btn-download" download="" style="background: #01579b;color: #fff;">Download</a></div>
                            
                       
                         </div>
                   </div>
      </div>
       <div class="widget ">
                    
                    <div class="widget-header">
                        <i class="icon-plus"></i>
                        <h3>Bank Account Details</h3>
                    </div> <!-- /widget-header -->
                    
                    <div class="widget-content">
                         <div class="container">
                            
                            <div class="control-group">                                         
                            <label class="control-label" for="account_holder">Account Holder Name </label>
                            <div class="controls">
                            <input type="text" class="span5" id="account_holder"  name="account_holder_name"
                            <?php if($employee->account_holder_name!= null): ?>
                            value="<?php echo e($employee->account_holder_name); ?>" 
                            <?php else: ?> 
                            placeholder="Null"
                            <?php endif; ?>
                            >
                            </div> <!-- /controls -->               
                            </div>

                             <div class="control-group">                                         
                        <label class="control-label" >Account Number</label>
                        <div class="controls">
                        <input type="text" class="span5" 
                         name="account_number"
                            <?php if($employee->account_number!= null): ?>
                            value="<?php echo e($employee->account_number); ?>" 
                            <?php else: ?> 
                            placeholder="Null"
                            <?php endif; ?>
                         >
                        </div> <!-- /controls -->               
                        </div>
                         <div class="control-group"> 

                        <label class="control-label" for="bank_number">Bank Name </label>
                        <div class="controls">
                        <input type="text" class="span5" id="bank_number" placeholder="Bank Number" name="bank_name"
                            <?php if($employee->bank_name!= null): ?>
                            value="<?php echo e($employee->bank_name); ?>" 
                            <?php else: ?> 
                            placeholder="Null"
                            <?php endif; ?>
                        >
                        </div> <!-- /controls -->               
                        </div>
                         <div class="control-group">                                         
                        <label class="control-label" for="ifsc_code">IFSC Code </label>
                        <div class="controls">
                        <input type="text" class="span5" id="ifsc_code" 
                         name="ifsc_code"
                           <?php if($employee->ifsc_code!= null): ?>
                            value="<?php echo e($employee->ifsc_code); ?>" 
                            <?php else: ?> 
                            placeholder="Null"
                            <?php endif; ?>

                         >
                        </div> <!-- /controls -->               
                        </div>
                         <div class="control-group">                                         
                        <label class="control-label" for="pan_number">Pan Number </label>
                        <div class="controls">
                        <input type="text" class="span5" id="pan_number" 
                         name="pan_number"
                         <?php if($employee->pan_number!= null): ?>
                            value="<?php echo e($employee->pan_number); ?>" 
                            <?php else: ?> 
                            placeholder="Null"
                            <?php endif; ?>  
                         >
                        </div> <!-- /controls -->               
                        </div>
                         <div class="control-group">                                         
                        <label class="control-label" for="branch">Branch </label>
                        <div class="controls">
                        <input type="text" class="span5" id="branch" 
                         name="branch"
                            <?php if($employee->branch!= null): ?>
                            value="<?php echo e($employee->branch); ?>" 
                            <?php else: ?> 
                            placeholder="Null"
                            <?php endif; ?>
                         >
                        </div> <!-- /controls -->               
                        </div>
                       
                         </div>
                   </div>
      </div>
       </div>
    
       
       
</div>
<div class="row">
   
       <div class="span12">
             <div class="widget ">
                    
                    <div class="widget-header">
                        <i class="icon-plus"></i>
                        <h3>Documents</h3>
                    </div> <!-- /widget-header -->
                    
                    <div class="widget-content">
                         <div class="container">
                        <div class="control-group file-back">                                    
                        <label class="control-label" for="resume">Resume (Pdf/Doc) </label>
                        <div class="controls">
                        <input type="file" class="span5 custom-file-input" id="resume" name="resume" style="height: 38px;"> 
                         <a 
                        <?php if($employee->resume_location!=null): ?>
                        href="<?php echo e(asset('storage/app/'.$employee->resume_location)); ?>"
                        <?php else: ?>
                        href="#"
                        <?php endif; ?>
                            class="btn btn-download" style="background: #01579b;color: #fff;">Download</a>
                        </div> <!-- /controls -->               
                        </div>
                       

                        <div class="control-group file-back">                                    
                        <label class="control-label" for="offer_letter">Offer Letter (Pdf/Doc) </label>
                        <div class="controls">
                        <input type="file" class="span5 custom-file-input" id="offer_letter" name="offer_letter" style="height: 38px;">
                          <a 
                        <?php if($employee->resume_location!=null): ?>
                        href="<?php echo e(asset('storage/app/'.$employee->offer_letter_location)); ?>"
                         <?php else: ?>
                        href="#"
                        <?php endif; ?>
                            class="btn btn-download" style="background: #01579b;color: #fff;">Download</a>
                        </div> <!-- /controls -->               
                        </div>

                        <div class="control-group file-back">                                    
                        <label class="control-label" for="joining_letter">Joining Letter (Pdf/Doc) </label>
                        <div class="controls">
                        <input type="file" class="span5 custom-file-input" id="joining_letter" name="joining_letter" style="height: 38px;">
                         <a 
                        <?php if($employee->resume_location!=null): ?>
                        href="<?php echo e(asset('storage/app/'.$employee->joining_letter_location)); ?>"
                         <?php else: ?>
                        href="#"
                        <?php endif; ?>   
                            class="btn btn-download" style="background: #01579b;color: #fff;">Download</a>
                        </div> <!-- /controls -->               
                        </div>

                        <div class="control-group file-back">                                    
                        <label class="control-label" for="designation">Contract and Agreement (Pdf/Doc)</label>
                        <div class="controls">
                        <input type="file" class="span5 custom-file-input"  name="contract_and_agreement" style="height: 38px;">
                        <a 
                        <?php if($employee->resume_location!=null): ?>
                        href="<?php echo e(asset('storage/app/'.$employee->id_proof_location)); ?>"
                         <?php else: ?>
                        href="#"
                        <?php endif; ?>
                            class="btn btn-download" style="background: #01579b;color: #fff;">Download</a>
                        </div> <!-- /controls -->               
                        </div>

                        <div class="control-group file-back">                                    
                        <label class="control-label" for="designation">ID Proof (Pdf/Doc) </label>
                        <div class="controls">
                        <input type="file" class="span5 custom-file-input"  name="id_proof" style="height: 38px;">
                         <a 
                         <?php if($employee->resume_location!=null): ?>
                         href="<?php echo e(asset('storage/app/'.$employee->id_proof_location)); ?>"
                        <?php else: ?>
                        href="#"
                        <?php endif; ?>
                          class="btn btn-download" style="background: #01579b;color: #fff;" download="">Download</a>
                        </div> <!-- /controls -->               
                        </div> 
                       
                         </div>
                   </div>
          </div>
               <button type="submit" class="btn btn-success">Update</button>
       </div>
       
</div>
</form>
<?php else: ?>
 <div class="container">
    
    <div class="row">
        
        <div class="span12">
            
            <div class="error-container">
                <h1>404</h1>
                
                <h2>Who! bad trip man. No more pixesl for you.</h2>
                
                <div class="error-details">
                    Sorry, an error has occured! Why not try going back to the <a href="<?php echo e(route('dashboard')); ?>">home page</a> or perhaps try following!
                    
                </div> <!-- /error-details -->
                
                <div class="error-actions">
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-large btn-primary">
                        <i class="icon-chevron-left"></i>
                        &nbsp;
                        Back to Dashboard                       
                    </a>
                    
                    
                    
                </div> <!-- /error-actions -->
                            
            </div> <!-- /error-container -->            
            
        </div> <!-- /span12 -->
        
    </div> <!-- /row -->
    
</div>
<?php endif; ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $( "#date_of_birth" ).datepicker();
    $('#date_of_birth2').datepicker();
    $('#department-section').change(function(e) {
       var v = document.getElementById('designation-section');
       $.get('<?php echo e(route('api-designation')); ?>', {_token:'<?php echo e(csrf_token()); ?>',department:this.value}, function(data, textStatus, xhr) {
            
             v.innerHTML =data;

       });
      
       
    });
    
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#preview_image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#image_preview").change(function(){
        readURL(this);
    });

    $(".option-auto").select2();
    $('.option-auto').change(function(event) {
        
    });
	$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
 
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>