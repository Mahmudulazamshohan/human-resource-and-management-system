<?php $__env->startSection('body'); ?>
<?php if($income_tax && $leave_pay && $overtimes &&$salary_type ): ?>
<div class="row">
    <div class="span12">
        <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Employee Info</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
               <div class="row">
                   <div class="span3" style="padding:10px; font-family: Impact, Charcoal, sans-serif;font-size: 22px;">
                    <?php if($em->image_preview_location!=null): ?>
                       <img src="<?php echo e(asset('storage/app/'.$em->image_preview_location)); ?>" height="200px" width="200px">
                    <?php else: ?>
                      <img src="<?php echo e(asset('public/img/blank-profile.png')); ?>" height="200px" width="200px">
                    <?php endif; ?>
                       <label>Name</label>
                       <input type="text" name="" placeholder="Name" value="<?php echo e($em->user->name); ?>">
                       <label>ID</label>
                       <input type="text" name="" placeholder="ID" value="<?php echo e($em->employee_id); ?>">
                   </div>
                   <div class="span2 mr100">
                       <label>Workday(hours)</label>
                       <input type="text" name="" class="span2" value="<?php echo e($current_salary->hours_worked/3600); ?>">
                   </div>
                   <div class="span2 mr100">
                       <label>Overtime(hours)</label>
                       <input type="text" name="" class="span2" value="<?php echo e($current_salary->overtime/3600); ?>">
                       <button  id="calculateBtn" class="btn btn-primary"> Calculate</button>
                   </div>
                   <div class="span2 mr100">
                       <label>Leave-days(hours)</label>
                       <input type="text" name="" class="span2" value="<?php echo e($shift_time*($lv->leaves + $absence)); ?>">
                   </div>
                   <div class="span2 mr100">
                       <label>Subsides</label>
                       <input type="text" name="" class="span2" value="<?php echo e($income_tax->percentage); ?>">
                   </div>
               </div>
            </div>
         </div>
    </div>
</div>



<div class="row" id="payroll-show">
    <div class="span12">
        <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Payroll</h3>
              <button style="float: right;margin-top: 7px;margin-right: 10px;" class="btn btn-success" id="print-payroll">Print</button>
            </div>
            <!-- /widget-header -->
            <div class="widget-content" id="payroll-print">
              <table  class="table table-bordered table-striped" cellspacing="0" width="100%" >
        <thead>
            <tr style="text-align: left;">
                <th>Payroll Category</th>
                <th>Hours</th>
                <th>Hourly Salary / Percentage %</th>
                <th>Total Amount</th> 
            </tr>
        </thead>
        <tfoot>
            <tr>
               
             
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
          
          <?php
            $wkday = floor(($current_salary->hours_worked/3600)*$salary_type->hourly_salary);
            $lvday = floor(($shift_time*($lv->leaves + $absence))*($leave_pay->hourly_salary));
            $overti = floor(($current_salary->overtime/3600)*$overtimes->hourly_salary) ;
            $intax=(($wkday-$lvday+$overti)/100)* $income_tax->percentage ;
            $subTotal = ($wkday-$lvday+$overti)-$intax;
          ?>
            <tr>
          
                <td>Working Days(Hours)</td>
                <td><?php echo e($current_salary->hours_worked/3600); ?> hours</td>
                <td><?php echo e($salary_type->hourly_salary); ?></td>
                <td>(+) <?php echo e($wkday); ?></td>
            </tr>
            <tr>
          
                <td>Leave Days(Hours)</td>
                <td><?php echo e($shift_time*($lv->leaves + $absence)); ?> hours</td>
                <td><?php echo e($leave_pay->hourly_salary); ?></td>
                <td>(-) <?php echo e($lvday); ?></td>
            </tr>
            <tr>
          
                <td>Overtime(Hours)</td>
                <td><?php echo e($current_salary->overtime/3600); ?> hours</td>
                <td><?php echo e($overtimes->hourly_salary); ?></td>
                <td><?php echo e($overti); ?></td>
            </tr>
            <tr>
          
                <td>Income Tax(Hours)</td>
                <td></td>
                <td><?php echo e($income_tax->percentage); ?>% of total amount</td>
                <td><?php echo e($intax); ?></td>
            </tr>
            <tr>
          
                <td></td>
                <td></td>
                <td style="text-align: right;">Sub Total</td>
                <td><?php echo e($subTotal); ?></td>
            </tr>
         
      
          
           
        </tbody>
    </table>
            </div>
         </div>
    </div>
</div>


<div class="row">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Working Days</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table id="example" class="display nowrap" cellspacing="0" width="100%" >
        <thead>
            <tr style="text-align: left;">
                <th>Employee ID</th>
                <th>Name</th>
                <th>Month</th>
                <th>Workday(hours)</th>
                <th>Overtime(hours)</th>
                <th>Tardiness</th>
              
                
            </tr>
        </thead>
        <tfoot>
            <tr>
               
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
            <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="text-align: center;">
                
                <td><?php echo e($s->employee_id); ?></td>
                <td><?php echo e($s->name); ?></td>
                <td><?php echo e($s->month); ?></td>
                <td><?php echo e(floor($s->hour_worked/3600)); ?> hours <?php echo e(($s->hour_worked/ 60) % 60); ?> minutes</td>
                <td><?php echo e(floor($s->overtime/3600)); ?> hours <?php echo e(($s->overtime/ 60) % 60); ?> minutes</td>
                <td><?php echo e($s->tardiness/3600); ?> hours <?php echo e(($s->tardiness/ 60) % 60); ?> minutes</td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
      
          
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>
<?php else: ?>
  <div class="row" style="margin-bottom: 30%;">
    <div class="span12">
        <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Employee Info</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content" style="padding:20px;">
               <?php if(!$salary_type): ?>
                <div class="alert alert-danger">
                 <button type="button" class="close" data-dismiss="alert">&times;</button>
                    Employee Salary Not Added
                </div>
                <a href="<?php echo e(route('salary-type')); ?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="icon-eye-open"></i> Add Salary Type</a>

               <?php endif; ?>
               <?php if(!$income_tax): ?>
                <div class="alert alert-danger">
                 <button type="button" class="close" data-dismiss="alert">&times;</button>
                    Income Tax Not Added
                </div>
                <a href="<?php echo e(route('income-tax')); ?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="icon-eye-open"></i> Add Income Tax</a>

               <?php endif; ?>
               <?php if(!$leave_pay): ?>
                <div class="alert alert-danger">
                 <button type="button" class="close" data-dismiss="alert">&times;</button>
                    Leave pay deduction Not Added
                </div>
                <a href="<?php echo e(route('leave-pay')); ?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="icon-eye-open"></i> Leave Pay Deduction</a>
               <?php endif; ?>
               <?php if(!$overtimes): ?>
                <div class="alert alert-danger">
                 <button type="button" class="close" data-dismiss="alert">&times;</button>
                  Overtime Pay Not Added
                </div>
                <a href="<?php echo e(route('overtime-pay')); ?>" class="btn btn-success" style="margin-bottom: 10px;"><i class="icon-eye-open"></i> Overtime Pay</a>

               <?php endif; ?>
            </div>
         </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
   $("#payroll-show").hide();
   $("#print-payroll").click(function() {
       printDiv();
   });

   function printDiv() 
{

  var divToPrint=document.getElementById('payroll-print');

  var newWin=window.open('','Print-Window');

  newWin.document.open();

  newWin.document.write('<html><style>td{border:1px solid #000;}</style><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

  newWin.document.close();

  setTimeout(function(){newWin.close();},10);

}
	$(document).ready(function() {
     $('#calculateBtn').click(function() {
        $("#payroll-show").show();
     });
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
        scrollX:true,
        scrollY:true,
    });

    
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>