<?php $__env->startSection('body'); ?>
<?php if($bonus): ?>
<div class="row">
	   
	   <div class="span12">
       	      			

          <div class="widget ">
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Edit Performance Bonus</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('update-performance-bonus')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">											
							
						<label class="control-label" for="user_id">Employee ID</label>
						<div class="controls">
						<select class="span7"  name="user_id" id="user_id">
							<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <?php if($em->user_id == $bonus->user_id): ?>
							  <option value="<?php echo e($em->user_id); ?>" selected> <?php echo e($em->employee_id); ?></option>
							  <?php else: ?>
							   <option value="<?php echo e($em->user_id); ?>"> <?php echo e($em->employee_id); ?></option>
							  <?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select> 
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
						<label class="control-label" for="date">Date</label>
						<div class="controls">
						<input type="text" class="span7" id="date" placeholder="" name="date" value="<?php echo e($bonus->date); ?>">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
						<label class="control-label" for="note">Note</label>
						<div class="controls">
						<textarea style="min-height: 70px;" class="span7" id="note" placeholder="" name="note"><?php echo e($bonus->note); ?></textarea>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
						<label class="control-label" for="number_of_star">Number of Star</label>
						<div class="controls">
						<input type="text" class="span7" id="number_of_star" placeholder="" name="number_of_star" value="<?php echo e($bonus->number_of_star); ?>">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
						<label class="control-label" for="bonus_amount">Bonus Amount</label>
						<div class="controls">
						<input type="text" class="span7" id="bonus_amount" placeholder="" name="bonus_amount" value="<?php echo e($bonus->bonus_amount); ?>">
						</div> <!-- /controls -->				
						</div>
						<button class="btn btn-primary">Submit</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<?php else: ?>
<div class="container">
    
    <div class="row">
        
        <div class="span12">
            
            <div class="error-container">
                <h1>404</h1>
                
                <h2>Who! bad trip man. No more pixesl for you.</h2>
                
                <div class="error-details">
                    Sorry, an error has occured! Why not try going back to the <a href="<?php echo e(route('dashboard')); ?>">home page</a> or perhaps try following!
                    
                </div> <!-- /error-details -->
                
                <div class="error-actions">
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-large btn-primary">
                        <i class="icon-chevron-left"></i>
                        &nbsp;
                        Back to Dashboard                       
                    </a>
                    
                    
                    
                </div> <!-- /error-actions -->
                            
            </div> <!-- /error-container -->            
            
        </div> <!-- /span12 -->
        
    </div> <!-- /row -->
    
</div>
<?php endif; ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#user_id').select2();
	$('#date').datepicker();
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>