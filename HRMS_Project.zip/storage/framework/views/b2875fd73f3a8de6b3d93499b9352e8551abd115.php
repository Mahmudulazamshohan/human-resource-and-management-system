<?php $__env->startSection('body'); ?>

<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>New Leaves</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('manager/store-leaves')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">											
							
						<label class="control-label" for="user_id">Employee ID</label>
						<div class="controls">
						<select class="span7" id="user_id"  name="user_id">
							<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <option value="<?php echo e($e->user_id); ?>"><?php echo e($e->employee_id); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="leave_type">Leave Type</label>
						<div class="controls">
						<select class="span7" id="leave_type"  name="leave_type">
							<?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <option value="<?php echo e($l->leave_type); ?>"><?php echo e($l->leave_type); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="date_from">Date From</label>
						<div class="controls">
						<input type="text" class="span7" id="date_from" placeholder="Date From" name="date_from">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="date_to">Date To</label>
						<div class="controls">
						<input type="text" class="span7" id="date_to" placeholder="Date To" name="date_to">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="applied_on">Applied On</label>
						<div class="controls">
						<input type="text" class="span7" id="applied_on" placeholder="Applied On" name="applied_on">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="leave_type">Reason</label>
						<div class="controls">
						<textarea class="span7" id="reason"  name="reason" style="min-height:70px; min-width:48.79941434846266%; "></textarea>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="comment">Comment</label>
						<div class="controls">
						
						<textarea class="span7" id="comment"  name="comment" style="min-height:70px;min-width:48.79941434846266%; "></textarea>
						</div> <!-- /controls -->				
						</div>

						
						<button class="btn btn-primary">Submit</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<div class="row">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Leave Type</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table id="example" class="display nowrap" cellspacing="0" width="100%">
        <thead>
            <tr style="text-align: left">
                <th>ID</th>	
                <th>Name</th>	
                <th>Leave Type</th>	
                <th>Date From</th>	
                <th>Date To</th>	
                <th>Applied On</th>	
                <th>Reason</th>	
                <th>Comment	</th>
                <th>Status</th>	
                <th>Action</th>
                
            </tr>
        </thead>
        <tfoot>
            <tr>
         
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
        	<?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                <td><?php echo e($ls->employee->employee_id); ?></td>
                <td><?php echo e($ls->user->name); ?></td>
                <td><?php echo e($ls->leave_type); ?></td>
                <td><?php echo e($ls->date_from); ?></td>
                <td><?php echo e($ls->date_to); ?></td>
                <td><?php echo e($ls->applied_on); ?></td>
                <td><?php echo e($ls->reason); ?></td>
                <td><?php echo e($ls->comment); ?></td>
                <?php if($ls->status == 'false'): ?>
                  <td>Pending</td>
                <?php else: ?>
                  <td>Accepted</td>
                <?php endif; ?>
                <td >
				<div class="controls">
				<div class="btn-group" >
				<a class="btn btn-success" href="#"><i class="icon-plus icon-white"></i> Action</a>
				<a class="btn btn-primary dropdown-toggle" data-toggle="dropdown" href="#"><span class="caret"></span></a>
				<ul class="dropdown-menu" style="min-width: 30px;">
					<?php if($ls->status == 'false'): ?>
	                  <li ><a href="<?php echo e(route('manager/accept-leaves',$ls->id)); ?>"><i class="icon-ok-sign"></i> Accept</a></li>
	                <?php else: ?>
                       <li ><a href="<?php echo e(route('manager/pending-leaves',$ls->id)); ?>"><i class="icon-remove-sign"></i> Pending</a></li>
	                <?php endif; ?>
				
				<li ><a href="<?php echo e(route('manager/edit-leaves',$ls->id)); ?>"><i class="icon-pencil"></i> Edit</a></li>
				<li ><a href="<?php echo e(route('manager/delete-leaves',$ls->id)); ?>"><i class="icon-trash"></i> Delete</a></li>
			
				</ul>
				</div>
				</div>
                 </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#user_id').select2();
	$('#leave_type').select2();
	$('#date_from').datepicker();
	$('#date_to').datepicker();
	$('#applied_on').datepicker();
	$(document).ready(function() {
    $('#example').DataTable({
    	scrollY:300,
    	scrollX:true
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>