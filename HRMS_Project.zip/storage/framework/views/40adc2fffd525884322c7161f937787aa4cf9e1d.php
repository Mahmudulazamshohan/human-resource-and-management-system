<?php $__env->startSection('body'); ?>

<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Violation Records</h3>
	  				</div> 
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('store-violation-record')); ?>" method="POST" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">											
							
						<label class="control-label" for="title">Employee ID</label>
						<div class="controls">
						<select class="span7" name="user_id" id="user_id">
                            <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($e->user_id); ?>"><?php echo e($e->employee_id); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                        </select>
						</div> <!-- /controls -->	

						</div>
                        <div class="control-group">                                         
                        <label class="control-label" for="date">Date</label>
                        <div class="controls">
                        <input class="span7" id="date" placeholder="Date" name="date">
                        </div> <!-- /controls -->               
                        </div>
                        <div class="control-group">                                         
                        <label class="control-label" for="violation_type">Violation Type</label>
                        <div class="controls">
                        <input class="span7" id="violation_type" placeholder="Violation Type" name="violation_type">
                        </div> <!-- /controls -->               
                        </div>

                        <div class="control-group">                                         
                        <label class="control-label" for="violation_statement">Violation Statement</label>
                        <div class="controls">
                        <input class="span7" id="violation_statement" placeholder="Violation Statement" name="violation_statement">
                        </div> <!-- /controls -->               
                        </div>

						<div class="control-group">											
						<label class="control-label" for="description_details">Description Details</label>
						<div class="controls">
						<textarea class="span7" id="description_details" placeholder="Description Details" name="description_details" style="min-height: 100px;"></textarea>
						</div> <!-- /controls -->				
						</div>

						

						<button class="btn btn-primary">Submit</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<div class="row">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Announcement List</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table   
            	class="table table-striped table-bordered" width="100%"  style="overflow: auto;" id="example">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Date</th>
                <th>Violation Type</th>
                <th>Violation Statement</th>
                <th>Description Details</th>  
                <th>Action</th>
                
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
           <?php $__currentLoopData = $vio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($v->employee->employee_id); ?></td>
                <td><?php echo e($v->user->name); ?></td>
                <td><?php echo e($v->date); ?></td>
                <td><?php echo e($v->violation_type); ?></td>
                <td><?php echo e($v->violation_statement); ?></td>
                <td><?php echo e($v->description_details); ?></td>
                <td>
                  <a href="<?php echo e(route('delete-violation-record',$v->id)); ?>" class="btn btn-small btn-danger"><i class="icon-remove"></i></a>
                </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
            
            
       
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>
<?php $__env->startSection('scripts'); ?>

<script src="<?php echo e(asset('public/js/jquery-ui-timepicker-addon.js')); ?>"></script>
<script type="text/javascript">
    $('#date').datepicker();
    $('#time').timepicker({
	      timeFormat: 'hh:mm tt'
    });
    $('#user_id').select2();
// 	$(document).ready(function() {
//     $('#example').DataTable( {
//         scrollY:300,
//         scrollX:true
//     } );
// } );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>