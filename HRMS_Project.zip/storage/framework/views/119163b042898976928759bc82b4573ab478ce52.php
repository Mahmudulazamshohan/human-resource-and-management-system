<?php $__env->startSection('body'); ?>

<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Salary Type</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('store-salary-type')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>


					<div class="control-group">											
							
						<label class="control-label" for="user_id">Employee ID</label>
						<div class="controls">
						<select class="span7" id="user_id" name="user_id">
							<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <option value="<?php echo e($em->user_id); ?>"><?php echo e($em->employee_id); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						</div> <!-- /controls -->				
						</div>
						 <div class="control-group">											
							
						<label class="control-label" for="hourly_salary">Hourly Salary</label>
						<div class="controls">
						<input type="text" class="span7" id="hourly_salary" placeholder="Hourly Salary" name="hourly_salary">
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
							
						<label class="control-label" for="weekly_salary">Weekly Salary</label>
						<div class="controls">
						<input type="text" class="span7" id="weekly_salary" placeholder="Weekly Salary" name="weekly_salary">
						</div> <!-- /controls -->				
						</div>
						
						<button class="btn btn-primary">Submit</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>
<div class="row">
	<div class="span12">
		<div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>Salary Type</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
            	<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Employee ID</th>
                <th>Name</th>
                <th>Hourly Salary</th>
                <th>Weekly Salary</th>
               
                <th>Action</th>
                
            </tr>
        </thead>
        <tfoot>
            <tr>
               <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                
            </tr>
        </tfoot>
        <tbody>
           <?php $__currentLoopData = $salary_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                 <td><?php echo e($st->employee->employee_id); ?></td>
                 <td><?php echo e($st->user->name); ?></td>
                <td><?php echo e($st->hourly_salary); ?></td>
                <td><?php echo e($st->weekly_salary); ?></td>
                <td>
				<a href="<?php echo e(route('edit-salary-type',$st->id)); ?>" class="btn btn-small btn-primary">
					<i class="btn-icon-only icon-pencil"> </i>
				</a>
					<a href="<?php echo e(route('delete-salary-type',$st->id)); ?>" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i>
				</a>
                 </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          
           
        </tbody>
    </table>
            </div>
         </div>
	</div>
</div>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#user_id').select2();
// 	$(document).ready(function() {
//     $('#example').DataTable();
// } );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>