<?php $__env->startSection('body'); ?>

<div class="row">
	   
	   <div class="span3">
        <div class="frame brtop" >
        	<div class="frame-body">
        		<?php if($employee->image_preview_location!=null): ?>
        		
        		  <img src="<?php echo e(asset('storage/app/'.$employee->image_preview_location)); ?>" class="img-circle">
        		<?php else: ?>
        		  <img src="<?php echo e(asset('public/img/default.jpg')); ?>" class="img-circle">
        		<?php endif; ?>
        		<h3>Name: <?php echo e($employee->user->name); ?></h3>
        		<p>Department: <?php echo e($employee->department); ?></p>
        		<p>Employee ID: <?php echo e($employee->employee_id); ?></p>
        		<hr>
        		<div class="flex-items ">
        			<div class="items pd10">
        				<div class="box">
        					<p class="txt"><?php echo e($leaves); ?></p>
        					<p>Leave</p>
        				</div>
        			</div>
        			<div class="items pd10">
        				<div class="box">
        					<p class="txt"><?php echo e($awards); ?></p>
        					<p>Awards</p>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
        <div class="frame">
        	<div class="frame-body">
        	  <div class="clock" style="background:url('<?php echo e(asset('public/css/images/clock-back.jpeg')); ?>');background-repeat: no-repeat;background-position: right;">
        	  	 <h1 class="year" id="year"></h1>
        	  	 <div class="clock-text" id="clock-text"></div>
        	  </div>
        	</div>
        </div>
	   
		   
      </div>
   <div class="span4">
	 <div class="frame brtop">
        	<div class="frame-body">
        	  <div class="header">Personal Details</div>
        	   <ul class="list">
        	   	 <li>
        	   	   <i class="icon-gift"></i> Birthday: 
                     <?php if($employee->date_of_birth!=null): ?> 
                       <?php echo e($employee->date_of_birth); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
        	   	 </li>
        	   	 <li>
                    <i class="icon-check-empty"></i> Gender: 
                     <?php if($employee->gender!=null): ?> 
                       <?php echo e($employee->gender); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
        	   	 </li>
        	   	 <li>
                    <i class="icon-gift"></i> Email: 
                     <?php if($employee->user->email!=null): ?> 
                       <?php echo e($employee->user->email); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
        	   	 </li>
        	   	 
        	   	 <li>
                    <i class="icon-phone"></i> Cellphone: 
                     <?php if($employee->phone_number!=null): ?> 
                       <?php echo e($employee->phone_number); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
        	   	 </li>
        	   	 <li>
                    <i class="icon-map-marker"></i> Local Address: 
                     <?php if($employee->date_of_birth!=null): ?> 
                       <?php echo e($employee->local_address); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
        	   	 </li>
        	   	 <li>
                    <i class="icon-map-marker"></i> Permanent Address: 
                     <?php if($employee->date_of_birth!=null): ?> 
                       <?php echo e($employee->permanent_address); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
        	   	 </li>
        	   	 
        	   	
        	   </ul>
        	</div>
     </div>
      <div class="frame brtop">
        	<div class="frame-body">
        	  <div class="header">Company Details</div>
        	   <ul class="list">
        	   	 <li><i class="icon-user"></i> Employee ID: 
                     <?php if($employee->employee_id!=null): ?> 
                       <?php echo e($employee->employee_id); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 <li><i class=" icon-briefcase"></i> Department: 
                     <?php if($employee->department!=null): ?> 
                       <?php echo e($employee->department); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 <li><i class="icon-th-list"></i> Designation: 
                     <?php if($employee->designation!=null): ?> 
                       <?php echo e($employee->designation); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 <li><i class="icon-calendar"></i> Date Hired: 
                     <?php if($employee->date_of_joining!=null): ?> 
                       <?php echo e($employee->date_of_joining); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 <li><i class="icon-credit-card"></i> Salary: 
                     <?php if($employee->date_of_birth!=null): ?> 
                       <?php echo e($employee->joining_salary); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 
        	   </ul>
        	</div>
     </div>
     <div class="frame brtop">
        	<div class="frame-body">
        	  <div class="header">Bank Details</div>
        	   <ul class="list">
        	   	 <li><i class="icon-credit-card"></i> Account Name:
                     <?php if($employee->account_holder_name!=null): ?> 
                       <?php echo e($employee->account_holder_name); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 <li><strong>#</strong> Account Number:
                     <?php if($employee->account_number!=null): ?> 
                       <?php echo e($employee->account_number); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 <li><i class=" icon-home"></i> Bank Name:
                     <?php if($employee->bank_name!=null): ?> 
                       <?php echo e($employee->bank_name); ?>

                     <?php else: ?>
                       Null
                     <?php endif; ?>
                 </li>
        	   	 
        	   </ul>
        	</div>
     </div>
   </div>
   <div class="span5">
   	 <div class="frame brtop">
        	<div class="frame-body">
        		 <div class="header"><i class="icon-bell"></i> Announcement</div>
        	     <ul class="list-notice">
                    
            <?php $__currentLoopData = $an; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	   	 <li>
                    <div class="flex-items">
                        <p style="text-align: left; font-weight: bold;"><?php echo e($a->title); ?></p>  
                        <p style="text-align: left;padding-right: 4px; font-weight: bold;"><?php echo e(substr($a->description,0,50).'.....'); ?></p>  
                        <p style="text-align: left;font-weight: bold;color:blue;"><?php echo e($a->updated_at); ?></p>
                        <a href="<?php echo e(route('employee/announcement',$a->id)); ?>" class="btn btn-small btn-success" style="max-height: 25px;"><i class="icon-eye-open"></i></a>
                    </div>
                   
                 </li>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	     </ul>
        	</div>
        </div>
       
   </div>
</div>
<script>
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('clock-text').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
    document.getElementById('year').innerHTML = new Date();
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
startTime();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.employee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>