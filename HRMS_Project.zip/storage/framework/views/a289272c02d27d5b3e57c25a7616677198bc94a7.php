<?php $__env->startSection('body'); ?>

<div class="row">
	   
	   <div class="span12">
       
          <div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-plus"></i>
	      				<h3>Edit Income Tax</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<div class="container">
						<form action="<?php echo e(route('update-income-tax')); ?>" method="POST">
							<?php echo e(csrf_field()); ?>

						 <div class="control-group">											
							<input type="hidden" name="employee_id" value="<?php echo e($income->user_id); ?>">
						<label class="control-label" for="user_id">Employee ID</label>
						<div class="controls">
						<select class="span7" id="user_id" name="user_id" disabled>
							<option><?php echo e($income->employee->employee_id); ?></option>
						</select>
						</div> <!-- /controls -->				
						</div>
						<div class="control-group">											
						<label class="control-label" for="percentage">Percentage %</label>
						<div class="controls">
						<input type="text" class="span7" id="percentage" placeholder="Percentage" name="percentage" value="<?php echo e($income->percentage); ?>">
						</div> <!-- /controls -->				
						</div>

						<div class="control-group">											
						<label class="control-label" for="current_salary">Current Salary</label>
						<div class="controls">
						<input type="text" class="span7" id="current_salary" placeholder="Current Salary" name="current_salary" value="<?php echo e($income->current_salary); ?>">
						</div> <!-- /controls -->				
						</div>

						

						<button class="btn btn-primary">Update</button>	
						<a href="" class="btn btn-danger">Cancel</a>
						</div>
						</form>
						
					</div>
				</div>
				
      		
      		
      		
		      		
	   </div>
	   
	   
</div>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#user_id').select2();
	$(document).ready(function() {
    $('#example').DataTable({
    	scrollX:true,
        scrollY: 200
    });
} );
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>